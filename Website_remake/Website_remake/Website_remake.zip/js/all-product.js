﻿let filter_col = document.querySelector('#filter-col')

document.querySelector('#filter-toggle').addEventListener('click', () => filter_col.classList.toggle('active'))

document.querySelector('#filter-close').addEventListener('click', () => filter_col.classList.toggle('active'))

let products = [
    {
        name: 'SẢN PHẨM 1',
        image1: './images/1.jpg',
        image2: './images/3.jpg',
        curr_price: '230.000 đ',
        old_price: '280.000 đ'
    },
    {
        name: 'SẢN PHẨM 2',
        image1: './images/2.jpg',
        image2: './images/4.jpg',
        curr_price: '230.000 đ',
        old_price: '280.000 đ'
    },
    {
        name: 'SẢN PHẨM 3',
        image1: './images/3.jpg',
        image2: './images/2.jpg',
        curr_price: '230.000 đ',
        old_price: '280.000 đ'
    },
    {
        name: 'SẢN PHẨM 4',
        image1: './images/4.jpg',
        image2: './images/1.jpg',
        curr_price: '230.000 đ',
        old_price: '280.000 đ'
    },
    {
        name: 'SẢN PHẨM 1',
        image1: './images/1.jpg',
        image2: './images/3.jpg',
        curr_price: '230.000 đ',
        old_price: '280.000 đ'
    },
    {
        name: 'SẢN PHẨM 2',
        image1: './images/2.jpg',
        image2: './images/4.jpg',
        curr_price: '230.000 đ',
        old_price: '280.000 đ'
    },
    {
        name: 'SẢN PHẨM 3',
        image1: './images/3.jpg',
        image2: './images/2.jpg',
        curr_price: '230.000 đ',
        old_price: '280.000 đ'
    },
    {
        name: 'SẢN PHẨM 4',
        image1: './images/4.jpg',
        image2: './images/1.jpg',
        curr_price: '230.000 đ',
        old_price: '280.000 đ'
    },
    {
        name: 'SẢN PHẨM 3',
        image1: './images/3.jpg',
        image2: './images/2.jpg',
        curr_price: '230.000 đ',
        old_price: '280.000 đ'
    },
]

let product_list = document.querySelector('#products')

renderProducts = (products) => {
    products.forEach(e => {
        let prod = `
            <div class="col-4 col-md-6 col-sm-12">
                <div class="product-card">
                    <div class="product-card-img">
                        <img src="${e.image1}" alt="">
                        <img src="${e.image2}" alt="">
                    </div>
                    <div class="product-card-info">
                    <div class="product-btn">
                        <button class="btn-flat-now btn-bag-hover btn-cart-add">
                            <i class='bx bxs-shopping-bag'></i>
                        </button>
                        <button class="btn-flat-like btn-like-hover btn-cart-add">
                            <i class='bx bxs-heart'></i>
                        </button>
                        <a href="TrangSanPhamChiTiet.html" class="btn-flat btn-hover btn-shop-now">chi tiết</a>
                    </div>
                        <div class="product-card-name">
                            ${e.name}
                        </div>
                        <div class="product-card-price">
                        <div class="curr-price">${e.curr_price}</div>
                            <del>${e.old_price}</del>
                        </div>
                    </div>
                </div>
            </div>
        `
        product_list.insertAdjacentHTML("beforeend", prod)
    })
}

renderProducts(products)